# Database Exercises
Please watch the tutorial for each exercise and then put your TWO HANDS on the keyboard to exercise.  

1. Tutorial 1: <a href="https://rumble.com/vd184t-database-exercise-1.html">Exercise 1</a>
2. Tutorial 2: <a href="https://rumble.com/vd18wb-database-exercise-2.html">Exercise 2</a>
3. Tutorial 3: <a href="https://rumble.com/vd191l-database-exercise-3.html">Exercise 3</a>
4. Tutorial 4: <a href="https://rumble.com/vd19cf-database-exercise-4-part-1.html">Exercise 4 Part 1</a>
5. Tutorial 5: <a href="https://rumble.com/vd19gb-database-exercise-4-part-2.html">Exercise 4 Part 2</a>
6. Tutorial 6: <a href="https://rumble.com/vd19mz-database-exercise-4-part-3.html">Exercise 4 Part 3</a>
